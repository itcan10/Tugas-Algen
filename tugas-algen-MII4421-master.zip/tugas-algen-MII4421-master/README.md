# tugas-algen-MII4421
Tugas Algoritma Genetika MII4421

Optimal Electricity
